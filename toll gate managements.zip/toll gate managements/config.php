<?php


define('DB_HOST', 'localhost');
define('DB_NAME', 'db_admin');
define('DB_USER', 'root');
define('DB_PASS', '');




?>