<?php 
$con=mysqli_connect('localhost','root','','db_admin');
if(!$con)
{
    die(mysqli_error("Error"+$con));
}
?>



