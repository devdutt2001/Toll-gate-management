<?php

include 'header.php';
include 'sidebar2.php';
?>

          <!-- Breadcrumbs-->
          <ol class="breadcrumb"
            <li class="breadcrumb-item" style="background-image: linear-gradient();">
              <a href="index.php"> <h2> TOLL GATE MANAGEMENT  SYSTEM </h2> </a>
            </li>
           
          </ol>

          <div class="bus_logo" align="center";>
            <a class="image full"><img src="image/hgt.webp" style="width:90%;" style="background-attachment: fixed;" style="background-size: contain;"  > </a>

         <!-- Page Content -->
          <h4></h4>
          
          <hr>
          <p> <h5> </h5></p>

<?php include 'footer.php'; ?>